import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/auth';
import { Users, Shield, User as UserIcon, ArrowUpCircle, ArrowDownCircle, Loader2, CheckCircle2 } from 'lucide-react';

interface UserProfile {
  id: string;
  email: string;
  display_name: string;
  role: 'admin' | 'user';
  created_at: string;
}

export default function UserManagement() {
  const { profile } = useAuth();
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [updatingId, setUpdatingId] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<string | null>(null);

  useEffect(() => {
    loadUsers();
  }, []);

  async function loadUsers() {
    setLoading(true);
    const { data } = await supabase
      .from('profiles')
      .select('id, email, display_name, role, created_at')
      .order('created_at', { ascending: true });
    setUsers(data as UserProfile[]);
    setLoading(false);
  }

  async function toggleRole(user: UserProfile) {
    const newRole = user.role === 'admin' ? 'user' : 'admin';
    setUpdatingId(user.id);
    setFeedback(null);
    const { error } = await supabase.rpc('set_user_role', {
      p_target_user: user.id,
      p_role: newRole,
    });
    if (error) {
      setFeedback('Could not update role. Please try again.');
    } else {
      setFeedback(`${user.email} is now ${newRole === 'admin' ? 'an admin' : 'a user'}.`);
      setUsers(prev => prev.map(u => u.id === user.id ? { ...u, role: newRole } : u));
    }
    setUpdatingId(null);
    setTimeout(() => setFeedback(null), 3000);
  }

  const adminCount = users.filter(u => u.role === 'admin').length;

  return (
    <div className="space-y-5">
      <div>
        <h3 className="text-lg font-bold text-white flex items-center gap-2">
          <div className="w-6 h-6 rounded bg-blue-600/20 border border-blue-600/40 flex items-center justify-center">
            <Users size={13} className="text-blue-400" />
          </div>
          User Management
        </h3>
        <p className="text-sm text-slate-400 mt-1">
          Manage who can access the platform and their role.
        </p>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-2 gap-3">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <div className="flex items-center gap-1.5 text-slate-400 mb-2">
            <Users size={14} />
            <span className="text-xs font-medium">Total Users</span>
          </div>
          <p className="text-2xl font-bold text-white font-mono">{users.length}</p>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <div className="flex items-center gap-1.5 text-blue-400 mb-2">
            <Shield size={14} />
            <span className="text-xs font-medium">Admins</span>
          </div>
          <p className="text-2xl font-bold text-white font-mono">{adminCount}</p>
        </div>
      </div>

      {feedback && (
        <div className="bg-emerald-950/40 border border-emerald-700/40 rounded-lg px-4 py-2.5 flex items-center gap-2">
          <CheckCircle2 size={14} className="text-emerald-400" />
          <p className="text-xs text-emerald-300">{feedback}</p>
        </div>
      )}

      {/* User list */}
      {loading ? (
        <div className="space-y-2">
          {Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="bg-slate-900 border border-slate-800 rounded-xl p-4 h-16 animate-pulse" />
          ))}
        </div>
      ) : (
        <div className="space-y-2">
          {users.map(user => {
            const isSelf = user.id === profile?.id;
            const isAdmin = user.role === 'admin';
            return (
              <div
                key={user.id}
                className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex items-center gap-3 hover:border-slate-700 transition-colors"
              >
                <div className={`w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 ${
                  isAdmin ? 'bg-blue-600/15 border border-blue-600/30' : 'bg-slate-800 border border-slate-700'
                }`}>
                  {isAdmin ? <Shield size={15} className="text-blue-400" /> : <UserIcon size={15} className="text-slate-400" />}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-white truncate">
                    {user.display_name || user.email}
                    {isSelf && <span className="text-slate-500 text-xs ml-2">(you)</span>}
                  </p>
                  <p className="text-xs text-slate-500 truncate">{user.email}</p>
                </div>
                <span className={`text-[10px] font-medium px-2 py-0.5 rounded-full flex-shrink-0 ${
                  isAdmin ? 'bg-blue-900/60 text-blue-400' : 'bg-slate-800 text-slate-400'
                }`}>
                  {user.role}
                </span>
                <button
                  onClick={() => toggleRole(user)}
                  disabled={updatingId === user.id || isSelf}
                  className="flex items-center gap-1 text-xs px-2.5 py-1.5 rounded-lg transition-colors flex-shrink-0 disabled:opacity-40 disabled:cursor-not-allowed"
                  title={isSelf ? 'You cannot change your own role' : ''}
                  style={{
                    color: isAdmin ? '#f87171' : '#60a5fa',
                    backgroundColor: isAdmin ? 'rgba(127,29,29,0.3)' : 'rgba(30,58,138,0.3)',
                  }}
                >
                  {updatingId === user.id ? (
                    <Loader2 size={12} className="animate-spin" />
                  ) : isAdmin ? (
                    <><ArrowDownCircle size={12} /> Demote</>
                  ) : (
                    <><ArrowUpCircle size={12} /> Promote</>
                  )}
                </button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
