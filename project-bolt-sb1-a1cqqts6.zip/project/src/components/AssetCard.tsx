import { Asset } from '@/lib/types';
import StatusBadge from './StatusBadge';
import { ExternalLink, Tag, Cpu } from 'lucide-react';

interface AssetCardProps {
  asset: Asset;
}

export default function AssetCard({ asset }: AssetCardProps) {
  return (
    <div className="group bg-slate-900 border border-slate-800 rounded-xl p-4 hover:border-slate-600 hover:bg-slate-800/60 transition-all duration-200 flex flex-col gap-3">
      {/* Header */}
      <div className="flex items-start justify-between gap-2">
        <div className="flex-1 min-w-0">
          <p className="text-xs text-blue-400 font-medium font-mono truncate">{asset.practice}</p>
          <h3 className="text-sm font-semibold text-white mt-0.5 leading-snug">{asset.asset_name || '—'}</h3>
        </div>
        <StatusBadge status={asset.status} size="sm" />
      </div>

      {/* Category */}
      {asset.category && (
        <div className="flex items-center gap-1.5 text-xs text-slate-400">
          <Tag size={11} />
          <span>{asset.category}</span>
          {asset.type_of_asset && (
            <>
              <span className="text-slate-700">·</span>
              <Cpu size={11} />
              <span>{asset.type_of_asset}</span>
            </>
          )}
        </div>
      )}

      {/* Purpose */}
      {asset.purpose && (
        <p className="text-xs text-slate-300 leading-relaxed line-clamp-2">{asset.purpose}</p>
      )}

      {/* Benefit */}
      {asset.benefit && (
        <div className="bg-slate-800/80 border border-slate-700/50 rounded-lg px-3 py-2">
          <p className="text-[10px] text-slate-500 font-medium uppercase tracking-wide mb-0.5">Benefit</p>
          <p className="text-xs text-emerald-400 leading-relaxed line-clamp-2">{asset.benefit}</p>
        </div>
      )}

      {/* Footer */}
      <div className="flex items-center justify-between pt-1 border-t border-slate-800">
        {asset.clients_implemented && (
          <span className="text-[10px] text-slate-500">
            Clients: <span className="text-slate-300">{asset.clients_implemented}</span>
          </span>
        )}
        {asset.link && (
          <a
            href={asset.link}
            target="_blank"
            rel="noopener noreferrer"
            className="ml-auto flex items-center gap-1 text-[10px] text-blue-400 hover:text-blue-300 transition-colors"
          >
            View <ExternalLink size={10} />
          </a>
        )}
      </div>
    </div>
  );
}
