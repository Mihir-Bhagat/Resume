import { useState } from 'react';
import { Network, LayoutDashboard, Shield, Menu, X, Activity, LogOut, User as UserIcon } from 'lucide-react';
import { useAuth } from '@/lib/auth';

type Page = 'dashboard' | 'osint' | 'admin';

interface NavProps {
  current: Page;
  onNavigate: (page: Page) => void;
}

export default function Nav({ current, onNavigate }: NavProps) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const { profile, signOut } = useAuth();

  const isAdmin = profile?.role === 'admin';

  const links: { id: Page; label: string; icon: React.ReactNode; adminOnly?: boolean }[] = [
    { id: 'dashboard', label: 'Overview', icon: <LayoutDashboard size={16} /> },
    { id: 'osint', label: 'OSINT Framework', icon: <Network size={16} /> },
    { id: 'admin', label: 'Admin Panel', icon: <Shield size={16} />, adminOnly: true },
  ];

  const visibleLinks = links.filter(l => !l.adminOnly || isAdmin);

  return (
    <header className="sticky top-0 z-50 border-b border-slate-800 glass">
      <div className="max-w-screen-xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between h-14">
          {/* Logo */}
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-md bg-blue-600 flex items-center justify-center">
              <Activity size={14} className="text-white" />
            </div>
            <span className="font-semibold text-sm tracking-tight text-white">
              A.T.D <span className="text-blue-400 font-mono">Feasibility</span>
            </span>
          </div>

          {/* Desktop nav */}
          <nav className="hidden sm:flex items-center gap-1">
            {visibleLinks.map(link => (
              <button
                key={link.id}
                onClick={() => onNavigate(link.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-all ${
                  current === link.id
                    ? 'bg-blue-600 text-white'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                {link.icon}
                {link.label}
              </button>
            ))}
          </nav>

          {/* Right side: user menu */}
          <div className="hidden sm:flex items-center gap-3">
            <div className="flex items-center gap-2 px-2.5 py-1 rounded-md bg-slate-800/60">
              <div className="w-5 h-5 rounded-full bg-slate-700 flex items-center justify-center">
                <UserIcon size={11} className="text-slate-300" />
              </div>
              <span className="text-xs text-slate-300 max-w-[120px] truncate">
                {profile?.display_name || profile?.email}
              </span>
              <span className={`text-[9px] font-medium px-1.5 py-0.5 rounded-full ${
                isAdmin ? 'bg-blue-900/60 text-blue-400' : 'bg-slate-700 text-slate-400'
              }`}>
                {isAdmin ? 'Admin' : 'User'}
              </span>
            </div>
            <button
              onClick={signOut}
              className="text-slate-400 hover:text-white p-1.5 rounded-md hover:bg-slate-800 transition-colors"
              title="Sign out"
            >
              <LogOut size={15} />
            </button>
          </div>

          {/* Mobile toggle */}
          <button
            className="sm:hidden text-slate-400 hover:text-white p-1"
            onClick={() => setMobileOpen(v => !v)}
          >
            {mobileOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>

        {/* Mobile nav */}
        {mobileOpen && (
          <div className="sm:hidden pb-3 flex flex-col gap-1">
            {visibleLinks.map(link => (
              <button
                key={link.id}
                onClick={() => { onNavigate(link.id); setMobileOpen(false); }}
                className={`flex items-center gap-2 px-3 py-2 rounded-md text-sm font-medium transition-all ${
                  current === link.id
                    ? 'bg-blue-600 text-white'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                {link.icon}
                {link.label}
              </button>
            ))}
            <div className="flex items-center justify-between px-3 py-2 mt-1 border-t border-slate-800">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-full bg-slate-700 flex items-center justify-center">
                  <UserIcon size={12} className="text-slate-300" />
                </div>
                <span className="text-xs text-slate-300">{profile?.email}</span>
                <span className={`text-[9px] font-medium px-1.5 py-0.5 rounded-full ${
                  isAdmin ? 'bg-blue-900/60 text-blue-400' : 'bg-slate-700 text-slate-400'
                }`}>
                  {isAdmin ? 'Admin' : 'User'}
                </span>
              </div>
              <button onClick={signOut} className="text-slate-400 hover:text-white">
                <LogOut size={16} />
              </button>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
