import { getStatusStyle } from '@/lib/types';

interface StatusBadgeProps {
  status: string;
  size?: 'sm' | 'md';
}

export default function StatusBadge({ status, size = 'md' }: StatusBadgeProps) {
  const style = getStatusStyle(status);
  const sizeClass = size === 'sm' ? 'text-[10px] px-1.5 py-0.5' : 'text-xs px-2 py-0.5';

  return (
    <span className={`inline-flex items-center gap-1 rounded-full font-medium ${style.bg} ${style.text} ${sizeClass}`}>
      <span className={`w-1.5 h-1.5 rounded-full ${style.dot} pulse-dot`} />
      {status || 'Unknown'}
    </span>
  );
}
