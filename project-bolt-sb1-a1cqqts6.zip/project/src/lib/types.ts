export interface Asset {
  id: string;
  practice: string;
  category: string;
  asset_name: string;
  purpose: string;
  benefit: string;
  link: string;
  type_of_asset: string;
  status: string;
  clients_implemented: string;
  comments: string;
  created_at: string;
}

export interface Deployment {
  id: string;
  account: string;
  assets_deployed: string;
  problem: string;
  category: string;
  mapped_category: string;
  practice: string;
  solution: string;
  value_level: string;
  effort_before: number;
  effort_after: number;
  created_at: string;
}

export interface UploadLog {
  id: string;
  filename: string;
  sheet_name: string;
  rows_parsed: number;
  rows_inserted: number;
  error_count: number;
  errors: string[];
  uploaded_at: string;
}

export type StatusType = 'Deployed' | 'POC On-going' | 'Assess/Prepare' | 'Rejected' | string;

export const STATUS_COLORS: Record<string, { bg: string; text: string; dot: string }> = {
  'Deployed': { bg: 'bg-emerald-100', text: 'text-emerald-800', dot: 'bg-emerald-500' },
  'POC On-going': { bg: 'bg-blue-100', text: 'text-blue-800', dot: 'bg-blue-500' },
  'Assess/Prepare': { bg: 'bg-amber-100', text: 'text-amber-800', dot: 'bg-amber-500' },
  'Rejected': { bg: 'bg-red-100', text: 'text-red-800', dot: 'bg-red-500' },
};

export const STATUS_BAR_COLORS: Record<string, string> = {
  'Deployed': 'bg-emerald-500',
  'POC On-going': 'bg-blue-500',
  'Assess/Prepare': 'bg-amber-400',
  'Rejected': 'bg-red-500',
};

export function getStatusStyle(status: string) {
  return STATUS_COLORS[status] ?? { bg: 'bg-gray-100', text: 'text-gray-700', dot: 'bg-gray-400' };
}
