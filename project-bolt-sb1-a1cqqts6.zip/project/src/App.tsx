import { useState } from 'react';
import { AuthProvider, useAuth } from '@/lib/auth';
import Nav from '@/components/Nav';
import Dashboard from '@/pages/Dashboard';
import OSINTFramework from '@/pages/OSINTFramework';
import AdminPanel from '@/pages/AdminPanel';
import Login from '@/pages/Login';
import { Activity, Loader2 } from 'lucide-react';

type Page = 'dashboard' | 'osint' | 'admin';

function AppContent() {
  const { session, profile, loading } = useAuth();
  const [page, setPage] = useState<Page>('dashboard');

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center">
            <Activity size={20} className="text-white" />
          </div>
          <div className="flex items-center gap-2 text-slate-400 text-sm">
            <Loader2 size={14} className="animate-spin" />
            Loading...
          </div>
        </div>
      </div>
    );
  }

  if (!session) {
    return <Login />;
  }

  const isAdmin = profile?.role === 'admin';
  const effectivePage = page === 'admin' && !isAdmin ? 'dashboard' : page;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      <Nav current={effectivePage} onNavigate={setPage} />
      <main>
        {effectivePage === 'dashboard' && <Dashboard />}
        {effectivePage === 'osint' && <OSINTFramework />}
        {effectivePage === 'admin' && isAdmin && <AdminPanel />}
      </main>
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
