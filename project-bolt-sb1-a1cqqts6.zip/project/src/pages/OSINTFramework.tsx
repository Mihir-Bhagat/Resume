import { useEffect, useState, useMemo, useRef, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { Deployment } from '@/lib/types';
import {
  Building2, Boxes, Zap, Search, ArrowLeft,
  AlertCircle, Lightbulb, Tag, ChevronRight,
  Plus, Minus, Maximize2, X, GitBranch
} from 'lucide-react';

interface TreeNode {
  id: string;
  label: string;
  type: 'account' | 'category' | 'asset';
  count: number;
  deployments?: Deployment[];
  children?: TreeNode[];
}

interface PositionedNode extends TreeNode {
  x: number;
  y: number;
  parentX?: number;
  parentY?: number;
  depth: number;
}

export default function OSINTFramework() {
  const [deployments, setDeployments] = useState<Deployment[]>([]);
  const [loading, setLoading] = useState(true);
  const [expandedNodes, setExpandedNodes] = useState<Set<string>>(new Set());
  const [selectedAsset, setSelectedAsset] = useState<Deployment | null>(null);
  const [search, setSearch] = useState('');
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const dragStart = useRef({ x: 0, y: 0, panX: 0, panY: 0 });
  const canvasRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    async function load() {
      setLoading(true);
      const { data } = await supabase
        .from('deployments')
        .select('*')
        .order('account');
      setDeployments(data ?? []);
      setLoading(false);
    }
    load();
  }, []);

  // Build the full tree from deployments
  const fullTree = useMemo((): TreeNode[] => {
    const accountMap = new Map<string, Map<string, Deployment[]>>();
    for (const d of deployments) {
      const acct = d.account || 'Unknown Account';
      if (!accountMap.has(acct)) accountMap.set(acct, new Map());
      const catKey = d.category || d.mapped_category || 'General';
      const catMap = accountMap.get(acct)!;
      if (!catMap.has(catKey)) catMap.set(catKey, []);
      catMap.get(catKey)!.push(d);
    }

    return Array.from(accountMap.entries()).map(([acctName, catMap]) => {
      const allDeps = Array.from(catMap.values()).flat();
      return {
        id: `acct::${acctName}`,
        label: acctName,
        type: 'account' as const,
        count: allDeps.length,
        children: Array.from(catMap.entries()).map(([catName, deps]) => ({
          id: `cat::${acctName}::${catName}`,
          label: catName,
          type: 'category' as const,
          count: deps.length,
          children: deps.map(d => ({
            id: `asset::${d.id}`,
            label: d.assets_deployed || 'Unnamed',
            type: 'asset' as const,
            count: 0,
            deployments: [d],
          })),
        })),
      };
    });
  }, [deployments]);

  // Filter tree by search
  const filteredTree = useMemo(() => {
    if (!search) return fullTree;
    const q = search.toLowerCase();
    return fullTree
      .map(acct => {
        const matchingCats = acct.children?.filter(cat => {
          if (cat.label.toLowerCase().includes(q)) return true;
          return cat.children?.some(asset =>
            asset.label.toLowerCase().includes(q)
          );
        }).map(cat => ({
          ...cat,
          children: cat.children?.filter(asset =>
            asset.label.toLowerCase().includes(q) || cat.label.toLowerCase().includes(q)
          ),
        }));
        const acctMatches = acct.label.toLowerCase().includes(q);
        if (acctMatches) return acct;
        if (matchingCats && matchingCats.length > 0) {
          return { ...acct, children: matchingCats };
        }
        return null;
      })
      .filter(Boolean) as TreeNode[];
  }, [fullTree, search]);

  // Flatten the tree into positioned nodes for rendering
  const positionedNodes = useMemo((): PositionedNode[] => {
    const nodes: PositionedNode[] = [];
    const NODE_W = 220;
    const H_GAP = 32;
    const V_GAP = 16;
    let currentY = 0;

    function measureSubtree(node: TreeNode): number {
      if (!expandedNodes.has(node.id) || !node.children || node.children.length === 0) {
        return 1;
      }
      let total = 0;
      for (const child of node.children) {
        total += measureSubtree(child);
      }
      return Math.max(total, 1);
    }

    function layout(node: TreeNode, depth: number, parentX?: number, parentY?: number) {
      const x = depth * (NODE_W + H_GAP);
      const subtreeSize = measureSubtree(node);
      const myY = currentY + subtreeSize / 2;

      nodes.push({
        ...node,
        x,
        y: myY,
        parentX,
        parentY,
        depth,
      });

      if (expandedNodes.has(node.id) && node.children && node.children.length > 0) {
        const childStartY = currentY;
        for (const child of node.children) {
          layout(child, depth + 1, x, myY);
        }
        const consumed = currentY - childStartY;
        if (consumed > 0) {
          currentY += Math.max(0, subtreeSize - consumed / 1);
        }
      }
      currentY += subtreeSize;
    }

    for (const acct of filteredTree) {
      currentY += 0.5;
      const startY = currentY;
      layout(acct, 0);
    }

    return nodes;
  }, [filteredTree, expandedNodes]);

  const totalRows = positionedNodes.length;
  const canvasHeight = useMemo(() => {
    if (positionedNodes.length === 0) return 600;
    const maxY = Math.max(...positionedNodes.map(n => n.y));
    return Math.max(600, (maxY + 2) * 56);
  }, [positionedNodes]);

  const NODE_W = 220;
  const ROW_H = 56;
  const H_GAP = 32;

  function toggleNode(id: string) {
    setExpandedNodes(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  function expandAll() {
    const all = new Set<string>();
    function walk(nodes: TreeNode[]) {
      for (const n of nodes) {
        if (n.type !== 'asset') all.add(n.id);
        if (n.children) walk(n.children);
      }
    }
    walk(filteredTree);
    setExpandedNodes(all);
  }

  function collapseAll() {
    setExpandedNodes(new Set());
  }

  // Pan handlers
  const onMouseDown = useCallback((e: React.MouseEvent) => {
    if (e.button !== 0) return;
    const target = e.target as HTMLElement;
    if (target.closest('[data-node]')) return;
    setIsDragging(true);
    dragStart.current = { x: e.clientX, y: e.clientY, panX: pan.x, panY: pan.y };
  }, [pan]);

  const onMouseMove = useCallback((e: React.MouseEvent) => {
    if (!isDragging) return;
    setPan({
      x: dragStart.current.panX + (e.clientX - dragStart.current.x),
      y: dragStart.current.panY + (e.clientY - dragStart.current.y),
    });
  }, [isDragging]);

  const onMouseUp = useCallback(() => setIsDragging(false), []);

  function resetView() {
    setZoom(1);
    setPan({ x: 0, y: 0 });
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="flex flex-col items-center gap-3">
          <div className="w-8 h-8 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
          <p className="text-slate-400 text-sm">Building framework graph...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <div className="border-b border-slate-800 bg-slate-900/50">
        <div className="max-w-screen-xl mx-auto px-4 sm:px-6 py-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <div className="w-6 h-6 rounded bg-blue-600/20 border border-blue-600/40 flex items-center justify-center">
                  <Boxes size={13} className="text-blue-400" />
                </div>
                OSINT Framework
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Interactive node graph · click nodes to expand · drag to pan
              </p>
            </div>

            {/* Search + controls */}
            <div className="flex items-center gap-2">
              <div className="relative w-full sm:w-56">
                <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                <input
                  type="text"
                  placeholder="Search nodes..."
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg pl-8 pr-4 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 transition-colors"
                />
              </div>
            </div>
          </div>

          {/* Toolbar */}
          <div className="flex items-center gap-2 mt-3">
            <button
              onClick={expandAll}
              className="text-[11px] bg-slate-800 hover:bg-slate-700 text-slate-300 px-2.5 py-1 rounded transition-colors"
            >
              Expand all
            </button>
            <button
              onClick={collapseAll}
              className="text-[11px] bg-slate-800 hover:bg-slate-700 text-slate-300 px-2.5 py-1 rounded transition-colors"
            >
              Collapse all
            </button>
            <div className="flex items-center gap-1 ml-2 border-l border-slate-700 pl-2">
              <button
                onClick={() => setZoom(z => Math.max(0.4, z - 0.15))}
                className="text-slate-400 hover:text-white p-1 rounded hover:bg-slate-800 transition-colors"
              >
                <Minus size={13} />
              </button>
              <span className="text-[10px] text-slate-500 font-mono w-9 text-center">{Math.round(zoom * 100)}%</span>
              <button
                onClick={() => setZoom(z => Math.min(2, z + 0.15))}
                className="text-slate-400 hover:text-white p-1 rounded hover:bg-slate-800 transition-colors"
              >
                <Plus size={13} />
              </button>
              <button
                onClick={resetView}
                className="text-slate-400 hover:text-white p-1 rounded hover:bg-slate-800 transition-colors ml-0.5"
                title="Reset view"
              >
                <Maximize2 size={12} />
              </button>
            </div>
            <span className="ml-auto text-[10px] text-slate-600 font-mono">
              {totalRows} nodes · {expandedNodes.size} expanded
            </span>
          </div>
        </div>
      </div>

      {/* Graph canvas */}
      <div
        ref={canvasRef}
        className="graph-canvas flex-1 relative overflow-hidden cursor-grab active:cursor-grabbing"
        style={{ minHeight: 'calc(100vh - 180px)' }}
        onMouseDown={onMouseDown}
        onMouseMove={onMouseMove}
        onMouseUp={onMouseUp}
        onMouseLeave={onMouseUp}
      >
        {deployments.length === 0 ? (
          <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
            <div className="w-14 h-14 rounded-full bg-slate-800 flex items-center justify-center mb-4">
              <GitBranch size={24} className="text-slate-600" />
            </div>
            <p className="text-slate-400 font-medium text-sm">No deployment data yet</p>
            <p className="text-slate-600 text-xs mt-1">Upload data in the Admin Panel to populate the graph.</p>
          </div>
        ) : filteredTree.length === 0 ? (
          <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
            <div className="w-14 h-14 rounded-full bg-slate-800 flex items-center justify-center mb-4">
              <Search size={24} className="text-slate-600" />
            </div>
            <p className="text-slate-400 font-medium text-sm">No nodes match "{search}"</p>
          </div>
        ) : (
          <div
            className="relative origin-top-left"
            style={{
              transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
              width: '100%',
              height: canvasHeight,
            }}
          >
            {/* SVG edges layer */}
            <svg
              className="absolute inset-0 pointer-events-none"
              style={{ width: '100%', height: canvasHeight, overflow: 'visible' }}
            >
              {positionedNodes.map(node => {
                if (node.parentX == null || node.parentY == null) return null;
                const x1 = node.parentX + NODE_W;
                const y1 = node.parentY * ROW_H + 18;
                const x2 = node.x;
                const y2 = node.y * ROW_H + 18;
                const midX = (x1 + x2) / 2;
                const isActive = expandedNodes.has(node.id);
                return (
                  <path
                    key={`edge-${node.id}`}
                    d={`M ${x1} ${y1} C ${midX} ${y1}, ${midX} ${y2}, ${x2} ${y2}`}
                    fill="none"
                    stroke={isActive ? '#3b82f6' : '#334155'}
                    strokeWidth={isActive ? 1.5 : 1}
                    className={isActive ? 'edge-active' : 'graph-edge'}
                    opacity={0.7}
                  />
                );
              })}
            </svg>

            {/* Nodes layer */}
            {positionedNodes.map(node => {
              const isExpanded = expandedNodes.has(node.id);
              const hasChildren = node.children && node.children.length > 0;
              const left = node.x;
              const top = node.y * ROW_H;

              if (node.type === 'account') {
                return (
                  <div
                    key={node.id}
                    data-node
                    className="absolute node-pop"
                    style={{ left, top, width: NODE_W }}
                  >
                    <div
                      onClick={() => hasChildren && toggleNode(node.id)}
                      className={`group bg-slate-900 border rounded-xl p-3 cursor-pointer transition-all duration-200 ${
                        isExpanded
                          ? 'border-blue-500/60 bg-blue-950/30 node-glow-pulse'
                          : 'border-slate-700 hover:border-blue-600/50'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-lg bg-blue-600/15 border border-blue-600/30 flex items-center justify-center flex-shrink-0">
                          <Building2 size={15} className="text-blue-400" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-semibold text-white truncate">{node.label}</p>
                          <p className="text-[10px] text-slate-500">
                            {node.count} asset{node.count !== 1 ? 's' : ''}
                          </p>
                        </div>
                        {hasChildren && (
                          <div className={`w-5 h-5 rounded flex items-center justify-center text-[10px] font-bold transition-all ${
                            isExpanded ? 'bg-blue-600 text-white rotate-90' : 'bg-slate-800 text-slate-400'
                          }`}>
                            <ChevronRight size={11} />
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              }

              if (node.type === 'category') {
                return (
                  <div
                    key={node.id}
                    data-node
                    className="absolute node-pop"
                    style={{ left, top, width: NODE_W }}
                  >
                    <div
                      onClick={() => hasChildren && toggleNode(node.id)}
                      className={`group bg-slate-900 border rounded-xl p-3 cursor-pointer transition-all duration-200 ${
                        isExpanded
                          ? 'border-emerald-500/60 bg-emerald-950/20'
                          : 'border-slate-700 hover:border-emerald-600/50'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-lg bg-emerald-600/15 border border-emerald-600/30 flex items-center justify-center flex-shrink-0">
                          <Tag size={14} className="text-emerald-400" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-slate-200 truncate">{node.label}</p>
                          <p className="text-[10px] text-slate-500">
                            {node.count} asset{node.count !== 1 ? 's' : ''}
                          </p>
                        </div>
                        {hasChildren && (
                          <div className={`w-5 h-5 rounded flex items-center justify-center text-[10px] font-bold transition-all ${
                            isExpanded ? 'bg-emerald-600 text-white rotate-90' : 'bg-slate-800 text-slate-400'
                          }`}>
                            <ChevronRight size={11} />
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              }

              // Asset node
              const dep = node.deployments?.[0];
              const isSelected = selectedAsset?.id === dep?.id;
              return (
                <div
                  key={node.id}
                  data-node
                  className="absolute node-pop"
                  style={{ left, top, width: NODE_W }}
                >
                  <div
                    onClick={() => dep && setSelectedAsset(isSelected ? null : dep)}
                    className={`group bg-slate-900 border rounded-xl p-3 cursor-pointer transition-all duration-200 ${
                      isSelected
                        ? 'border-amber-500 bg-amber-950/30'
                        : 'border-slate-700 hover:border-amber-500/50 hover:bg-slate-800/60'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-lg bg-amber-500/15 border border-amber-500/30 flex items-center justify-center flex-shrink-0">
                        <Zap size={13} className="text-amber-400" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-slate-200 truncate">{node.label}</p>
                        {dep?.value_level && (
                          <span className={`inline-block text-[9px] px-1.5 py-0.5 rounded-full mt-0.5 ${
                            dep.value_level === 'High' ? 'bg-emerald-900/60 text-emerald-400' :
                            dep.value_level === 'Medium' ? 'bg-amber-900/60 text-amber-400' :
                            'bg-slate-800 text-slate-400'
                          }`}>
                            {dep.value_level}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Asset detail drawer */}
      {selectedAsset && (
        <div className="fixed inset-0 z-50 flex justify-end" onClick={() => setSelectedAsset(null)}>
          <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" />
          <div
            className="relative w-full max-w-md h-full bg-slate-900 border-l border-slate-700 shadow-2xl overflow-y-auto scrollbar-thin node-appear"
            onClick={e => e.stopPropagation()}
          >
            {/* Drawer header */}
            <div className="sticky top-0 bg-slate-900 border-b border-slate-800 px-5 py-4 flex items-start justify-between gap-3 z-10">
              <div className="flex items-start gap-3 flex-1 min-w-0">
                <div className="w-10 h-10 rounded-lg bg-amber-500/15 border border-amber-500/30 flex items-center justify-center flex-shrink-0">
                  <Zap size={18} className="text-amber-400" />
                </div>
                <div className="min-w-0">
                  <p className="text-[10px] text-amber-500 font-mono uppercase tracking-widest">Asset Detail</p>
                  <h3 className="text-base font-bold text-white leading-tight mt-0.5">
                    {selectedAsset.assets_deployed || '—'}
                  </h3>
                  {selectedAsset.mapped_category && (
                    <p className="text-xs text-slate-500 mt-0.5">{selectedAsset.mapped_category}</p>
                  )}
                </div>
              </div>
              <button
                onClick={() => setSelectedAsset(null)}
                className="text-slate-500 hover:text-white p-1 rounded hover:bg-slate-800 transition-colors flex-shrink-0"
              >
                <X size={18} />
              </button>
            </div>

            {/* Drawer body */}
            <div className="px-5 py-5 space-y-5">
              <DetailBlock icon={<Building2 size={13} className="text-blue-400" />} label="Account">
                <p className="text-sm text-slate-200">{selectedAsset.account}</p>
              </DetailBlock>

              {selectedAsset.problem && (
                <DetailBlock icon={<AlertCircle size={13} className="text-red-400" />} label="Problem">
                  <p className="text-sm text-slate-300 leading-relaxed">{selectedAsset.problem}</p>
                </DetailBlock>
              )}

              {selectedAsset.solution && (
                <DetailBlock icon={<Lightbulb size={13} className="text-yellow-400" />} label="Solution">
                  <p className="text-sm text-slate-300 leading-relaxed">{selectedAsset.solution}</p>
                </DetailBlock>
              )}

              <div className="grid grid-cols-2 gap-3">
                {selectedAsset.category && (
                  <DetailBlock icon={<Tag size={12} className="text-emerald-400" />} label="Category" compact>
                    <p className="text-sm text-slate-200">{selectedAsset.category}</p>
                  </DetailBlock>
                )}
                {selectedAsset.value_level && (
                  <DetailBlock icon={<Zap size={12} className="text-amber-400" />} label="Value" compact>
                    <span className={`inline-block text-xs font-medium px-2 py-0.5 rounded-full ${
                      selectedAsset.value_level === 'High' ? 'bg-emerald-900/60 text-emerald-400' :
                      selectedAsset.value_level === 'Medium' ? 'bg-amber-900/60 text-amber-400' :
                      'bg-slate-800 text-slate-400'
                    }`}>
                      {selectedAsset.value_level}
                    </span>
                  </DetailBlock>
                )}
              </div>

              {(selectedAsset.effort_before > 0 || selectedAsset.effort_after > 0) && (
                <DetailBlock icon={<ArrowLeft size={13} className="text-blue-400 rotate-90" />} label="Effort (hours per week)">
                  <div className="flex items-center gap-3 mt-2">
                    <div className="flex-1 bg-slate-800 rounded-lg p-3 text-center">
                      <p className="text-[10px] text-slate-500 uppercase tracking-widest">Before</p>
                      <p className="text-2xl font-bold text-red-400 font-mono mt-1">{selectedAsset.effort_before}</p>
                    </div>
                    <ChevronRight size={20} className="text-slate-600" />
                    <div className="flex-1 bg-slate-800 rounded-lg p-3 text-center">
                      <p className="text-[10px] text-slate-500 uppercase tracking-widest">After</p>
                      <p className="text-2xl font-bold text-emerald-400 font-mono mt-1">{selectedAsset.effort_after}</p>
                    </div>
                    {selectedAsset.effort_before > 0 && (
                      <div className="flex-1 bg-blue-950/40 border border-blue-800/40 rounded-lg p-3 text-center">
                        <p className="text-[10px] text-slate-500 uppercase tracking-widest">Saved</p>
                        <p className="text-2xl font-bold text-blue-400 font-mono mt-1">
                          {selectedAsset.effort_before - selectedAsset.effort_after}h
                        </p>
                      </div>
                    )}
                  </div>
                </DetailBlock>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function DetailBlock({
  icon, label, children, compact
}: {
  icon: React.ReactNode; label: string; children: React.ReactNode; compact?: boolean;
}) {
  return (
    <div className={compact ? '' : 'bg-slate-800/40 rounded-xl p-4 border border-slate-800'}>
      <div className="flex items-center gap-1.5 mb-1.5">
        {icon}
        <span className="text-[10px] text-slate-500 uppercase tracking-widest font-medium">{label}</span>
      </div>
      {children}
    </div>
  );
}
