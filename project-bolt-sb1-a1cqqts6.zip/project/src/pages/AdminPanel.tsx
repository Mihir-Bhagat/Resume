import { useState, useCallback, useRef } from 'react';
import * as XLSX from 'xlsx';
import { supabase } from '@/lib/supabase';
import { Asset, Deployment } from '@/lib/types';
import UserManagement from '@/components/UserManagement';
import {
  Upload, FileSpreadsheet, CheckCircle2, AlertCircle,
  Download, Trash2, Database, FileUp, X, Loader2, Info, Users
} from 'lucide-react';

interface ParseRow {
  [key: string]: any;
}

interface ParseResult {
  sheetName: string;
  rows: ParseRow[];
  totalRows: number;
}

interface UploadSummary {
  filename: string;
  sheetName: string;
  rowsParsed: number;
  rowsInserted: number;
  errors: string[];
}

const SHEET2_FIELDS = [
  'Practice', 'Category', 'Asset Name', 'Purpose / Benefit', 'Benefit',
  'Link', 'Type of Asset', 'Status', 'Clients Implemented', 'Comments'
];

const ASSET_SUMMARY_FIELDS = [
  'Account', 'Assets Deployed', 'Problem', 'Category', 'Mapped Category',
  'Practice', 'Solution', 'Value', 'Effort Before', 'Effort After'
];

type TargetTable = 'assets' | 'deployments';

export default function AdminPanel() {
  const [dragActive, setDragActive] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [parsing, setParsing] = useState(false);
  const [parseResults, setParseResults] = useState<ParseResult[]>([]);
  const [targetTable, setTargetTable] = useState<TargetTable>('assets');
  const [uploading, setUploading] = useState(false);
  const [summary, setSummary] = useState<UploadSummary | null>(null);
  const [previewOpen, setPreviewOpen] = useState(true);
  const [activeTab, setActiveTab] = useState<'upload' | 'users'>('upload');
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFile = useCallback((f: File) => {
    setFile(f);
    setParseResults([]);
    setSummary(null);
    setParsing(true);

    const reader = new FileReader();
    reader.onload = e => {
      try {
        const data = new Uint8Array(e.target!.result as ArrayBuffer);
        const wb = XLSX.read(data, { type: 'array' });
        const results: ParseResult[] = wb.SheetNames.map(name => ({
          sheetName: name,
          rows: XLSX.utils.sheet_to_json<ParseRow>(wb.Sheets[name]),
          totalRows: 0,
        }));
        for (const r of results) r.totalRows = r.rows.length;
        setParseResults(results);

        // Auto-select target table based on sheet name
        const names = wb.SheetNames.map(n => n.toLowerCase());
        if (names.some(n => n.includes('summary') || n.includes('category'))) {
          setTargetTable('deployments');
        } else if (names.some(n => n.includes('sheet2') || n.includes('repository') || n.includes('asset'))) {
          setTargetTable('assets');
        }
      } catch (err) {
        setSummary({
          filename: f.name,
          sheetName: '',
          rowsParsed: 0,
          rowsInserted: 0,
          errors: ['Failed to parse file: ' + (err as Error).message],
        });
      }
      setParsing(false);
    };
    reader.onerror = () => {
      setParsing(false);
      setSummary({
        filename: f.name,
        sheetName: '',
        rowsParsed: 0,
        rowsInserted: 0,
        errors: ['Could not read the file.'],
      });
    };
    reader.readAsArrayBuffer(f);
  }, []);

  const onDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragActive(false);
    const f = e.dataTransfer.files?.[0];
    if (f) handleFile(f);
  }, [handleFile]);

  const onDragOver = (e: React.DragEvent) => { e.preventDefault(); setDragActive(true); };
  const onDragLeave = (e: React.DragEvent) => { e.preventDefault(); setDragActive(false); };

  function normalizeKey(k: string): string {
    return k.toLowerCase().replace(/[^a-z0-9]/g, ' ').replace(/\s+/g, ' ').trim();
  }

  function findField(row: ParseRow, candidates: string[]): string {
    const normalized = new Map<string, string>();
    for (const k of Object.keys(row)) {
      normalized.set(normalizeKey(k), k);
    }
    for (const candidate of candidates) {
      const target = normalizeKey(candidate);
      if (normalized.has(target)) return normalized.get(target)!;
      // partial match
      for (const [normKey, origKey] of normalized) {
        if (normKey.includes(target) || target.includes(normKey)) return origKey;
      }
    }
    return '';
  }

  function getString(row: ParseRow, candidates: string[]): string {
    const key = findField(row, candidates);
    if (!key) return '';
    const val = row[key];
    return val == null ? '' : String(val).trim();
  }

  function getNumber(row: ParseRow, candidates: string[]): number {
    const val = getString(row, candidates).replace(/[^\d.]/g, '');
    return val ? parseFloat(val) : 0;
  }

  async function clearTable() {
    if (!confirm(`Delete ALL data from the "${targetTable}" table? This cannot be undone.`)) return;
    const { error } = await supabase.from(targetTable).delete().neq('id', '00000000-0000-0000-0000-000000000000');
    if (error) {
      setSummary({
        filename: file?.name ?? '',
        sheetName: '',
        rowsParsed: 0,
        rowsInserted: 0,
        errors: ['Failed to clear table: ' + error.message],
      });
    } else {
      setSummary({
        filename: file?.name ?? '',
        sheetName: '',
        rowsParsed: 0,
        rowsInserted: 0,
        errors: [],
      });
    }
  }

  async function uploadData() {
    if (parseResults.length === 0) return;
    setUploading(true);
    const allErrors: string[] = [];
    let totalInserted = 0;
    let totalParsed = 0;

    // Use the first sheet (or let user pick)
    const sheet = parseResults[0];
    totalParsed = sheet.rows.length;

    try {
      if (targetTable === 'assets') {
        const records: Omit<Asset, 'id' | 'created_at'>[] = [];
        sheet.rows.forEach((row, idx) => {
          const practice = getString(row, ['Practice']);
          const assetName = getString(row, ['Asset Name', 'Assets Deployed', 'Asset']);
          if (!practice && !assetName) {
            allErrors.push(`Row ${idx + 2}: missing both Practice and Asset Name — skipped`);
            return;
          }
          records.push({
            practice,
            category: getString(row, ['Category']),
            asset_name: assetName,
            purpose: getString(row, ['Purpose', 'Purpose / Benefit']),
            benefit: getString(row, ['Benefit', 'Purpose / Benefit', 'Purpose and Benefit']),
            link: getString(row, ['Link', 'URL', 'Hyperlink']),
            type_of_asset: getString(row, ['Type of Asset', 'Type', 'Asset Type']),
            status: getString(row, ['Status']),
            clients_implemented: getString(row, ['Clients Implemented', 'Clients', 'Implemented']),
            comments: getString(row, ['Comments', 'Notes', 'Remarks']),
          });
        });

        if (records.length > 0) {
          const { error } = await supabase.from('assets').insert(records);
          if (error) allErrors.push('Database error: ' + error.message);
          else totalInserted = records.length;
        }
      } else {
        const records: Omit<Deployment, 'id' | 'created_at'>[] = [];
        sheet.rows.forEach((row, idx) => {
          const account = getString(row, ['Account', 'Company', 'Client']);
          const assetDeployed = getString(row, ['Assets Deployed', 'Asset', 'Asset Name']);
          if (!account && !assetDeployed) {
            allErrors.push(`Row ${idx + 2}: missing both Account and Assets Deployed — skipped`);
            return;
          }
          records.push({
            account,
            assets_deployed: assetDeployed,
            problem: getString(row, ['Problem', 'Problem Statement']),
            category: getString(row, ['Category']),
            mapped_category: getString(row, ['Mapped Category', 'Mapped Category (normalized)']),
            practice: getString(row, ['Practice']),
            solution: getString(row, ['Solution', 'Solution Implemented']),
            value_level: getString(row, ['Value', 'Value Level']),
            effort_before: getNumber(row, ['Effort Before', 'Effort Before (hrs/wk)', 'Before']),
            effort_after: getNumber(row, ['Effort After', 'Effort After (hrs/wk)', 'After']),
          });
        });

        if (records.length > 0) {
          const { error } = await supabase.from('deployments').insert(records);
          if (error) allErrors.push('Database error: ' + error.message);
          else totalInserted = records.length;
        }
      }

      // Log upload
      await supabase.from('upload_logs').insert({
        filename: file?.name ?? 'unknown',
        sheet_name: sheet.sheetName,
        rows_parsed: totalParsed,
        rows_inserted: totalInserted,
        error_count: allErrors.length,
        errors: allErrors,
      });

      setSummary({
        filename: file?.name ?? '',
        sheetName: sheet.sheetName,
        rowsParsed: totalParsed,
        rowsInserted: totalInserted,
        errors: allErrors,
      });
    } catch (err) {
      allErrors.push('Unexpected error: ' + (err as Error).message);
      setSummary({
        filename: file?.name ?? '',
        sheetName: sheet.sheetName,
        rowsParsed: totalParsed,
        rowsInserted: totalInserted,
        errors: allErrors,
      });
    }
    setUploading(false);
  }

  function reset() {
    setFile(null);
    setParseResults([]);
    setSummary(null);
    setPreviewOpen(true);
    if (inputRef.current) inputRef.current.value = '';
  }

  return (
    <div className="min-h-screen">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8">
        {/* Header */}
        <div className="mb-6">
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <div className="w-6 h-6 rounded bg-blue-600/20 border border-blue-600/40 flex items-center justify-center">
              <Database size={13} className="text-blue-400" />
            </div>
            Admin Panel
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            Upload Excel or CSV files to populate the shared dashboard data.
          </p>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 mb-6 border-b border-slate-800">
          <button
            onClick={() => setActiveTab('upload')}
            className={`flex items-center gap-1.5 px-4 py-2.5 text-sm font-medium border-b-2 transition-all ${
              activeTab === 'upload'
                ? 'border-blue-500 text-white'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <Upload size={14} />
            Data Upload
          </button>
          <button
            onClick={() => setActiveTab('users')}
            className={`flex items-center gap-1.5 px-4 py-2.5 text-sm font-medium border-b-2 transition-all ${
              activeTab === 'users'
                ? 'border-blue-500 text-white'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <Users size={14} />
            User Management
          </button>
        </div>

        {/* Success banner */}
        {summary && summary.errors.length === 0 && summary.rowsInserted > 0 && (
          <div className="mb-6 bg-emerald-950/40 border border-emerald-700/40 rounded-xl p-4 flex items-start gap-3">
            <CheckCircle2 size={18} className="text-emerald-400 flex-shrink-0 mt-0.5" />
            <div className="flex-1">
              <p className="text-sm text-emerald-300 font-medium">Upload successful</p>
              <p className="text-xs text-emerald-400/70 mt-0.5">
                {summary.rowsInserted} of {summary.rowsParsed} rows from "{summary.sheetName}" saved to {targetTable}.
              </p>
            </div>
            <button onClick={() => setSummary(null)} className="text-emerald-700 hover:text-emerald-500"><X size={14} /></button>
          </div>
        )}

        {/* Error/partial banner */}
        {summary && summary.errors.length > 0 && (
          <div className="mb-6 bg-red-950/40 border border-red-700/40 rounded-xl p-4">
            <div className="flex items-start gap-3">
              <AlertCircle size={18} className="text-red-400 flex-shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="text-sm text-red-300 font-medium">
                  {summary.rowsInserted > 0 ? 'Upload completed with issues' : 'Upload failed'}
                </p>
                <p className="text-xs text-red-400/70 mt-0.5">
                  {summary.rowsInserted} of {summary.rowsParsed} rows inserted · {summary.errors.length} error{summary.errors.length !== 1 ? 's' : ''}
                </p>
                <ul className="mt-2 space-y-1 max-h-32 overflow-y-auto scrollbar-thin">
                  {summary.errors.slice(0, 10).map((err, i) => (
                    <li key={i} className="text-xs text-red-400/80 font-mono">• {err}</li>
                  ))}
                </ul>
              </div>
              <button onClick={() => setSummary(null)} className="text-red-700 hover:text-red-500"><X size={14} /></button>
            </div>
          </div>
        )}

        {activeTab === 'users' && <UserManagement />}

        {activeTab === 'upload' && (
        <>
        {/* Upload card */}
        {!parseResults.length && (
          <div
            onDrop={onDrop}
            onDragOver={onDragOver}
            onDragLeave={onDragLeave}
            className={`border-2 border-dashed rounded-2xl p-10 sm:p-14 text-center transition-all ${
              dragActive ? 'drop-zone-active border-blue-500' : 'border-slate-700'
            }`}
          >
            <div className="w-14 h-14 rounded-2xl bg-slate-800 flex items-center justify-center mx-auto mb-4">
              {parsing ? (
                <Loader2 size={24} className="text-blue-400 animate-spin" />
              ) : (
                <FileUp size={24} className="text-slate-500" />
              )}
            </div>
            <p className="text-white font-medium text-sm">
              {parsing ? 'Parsing file...' : 'Drop your Excel file here'}
            </p>
            <p className="text-xs text-slate-500 mt-1">or click to browse · .xlsx, .xls, .csv supported</p>
            <input
              ref={inputRef}
              type="file"
              accept=".xlsx,.xls,.csv"
              className="hidden"
              onChange={e => { const f = e.target.files?.[0]; if (f) handleFile(f); }}
            />
            <button
              onClick={() => inputRef.current?.click()}
              disabled={parsing}
              className="mt-4 inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white text-sm font-medium px-4 py-2 rounded-lg transition-colors disabled:opacity-50"
            >
              <Upload size={14} />
              Choose File
            </button>
          </div>
        )}

        {/* File info + sheet selector + preview */}
        {parseResults.length > 0 && (
          <div className="space-y-5">
            {/* File card */}
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-emerald-600/10 border border-emerald-600/20 flex items-center justify-center flex-shrink-0">
                <FileSpreadsheet size={18} className="text-emerald-400" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm text-white font-medium truncate">{file?.name}</p>
                <p className="text-xs text-slate-500 mt-0.5">
                  {parseResults.length} sheet{parseResults.length !== 1 ? 's' : ''} · {parseResults.reduce((a, b) => a + b.totalRows, 0)} total rows
                </p>
              </div>
              <button onClick={reset} className="text-slate-500 hover:text-slate-300 text-xs px-2 py-1">
                Remove
              </button>
            </div>

            {/* Sheet tabs */}
            {parseResults.length > 1 && (
              <div className="flex flex-wrap gap-2">
                {parseResults.map((r, i) => (
                  <button
                    key={r.sheetName}
                    onClick={() => setParseResults(prev => [prev[i], ...prev.filter((_, j) => j !== i)])}
                    className="text-xs bg-slate-800 hover:bg-slate-700 text-slate-300 px-3 py-1.5 rounded-md transition-colors"
                  >
                    {r.sheetName} <span className="text-slate-500">({r.totalRows})</span>
                  </button>
                ))}
              </div>
            )}

            {/* Target table selector */}
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
              <div className="flex items-center gap-2 mb-3">
                <Info size={13} className="text-blue-400" />
                <span className="text-xs text-slate-400 font-medium">Choose where to save this data</span>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={() => setTargetTable('assets')}
                  className={`text-left p-3 rounded-lg border transition-all ${
                    targetTable === 'assets'
                      ? 'border-blue-500 bg-blue-600/10'
                      : 'border-slate-700 bg-slate-800/40 hover:border-slate-600'
                  }`}
                >
                  <p className="text-sm font-medium text-white">Asset Repository</p>
                  <p className="text-xs text-slate-400 mt-0.5">Sheet2-style data: practice, category, asset name, status</p>
                </button>
                <button
                  onClick={() => setTargetTable('deployments')}
                  className={`text-left p-3 rounded-lg border transition-all ${
                    targetTable === 'deployments'
                      ? 'border-blue-500 bg-blue-600/10'
                      : 'border-slate-700 bg-slate-800/40 hover:border-slate-600'
                  }`}
                >
                  <p className="text-sm font-medium text-white">Deployments / OSINT</p>
                  <p className="text-xs text-slate-400 mt-0.5">Summary-style data: account, asset, problem, solution, effort</p>
                </button>
              </div>

              {/* Expected fields */}
              <div className="mt-3 pt-3 border-t border-slate-800">
                <p className="text-[10px] text-slate-500 uppercase tracking-widest mb-2">Expected Columns</p>
                <div className="flex flex-wrap gap-1.5">
                  {(targetTable === 'assets' ? SHEET2_FIELDS : ASSET_SUMMARY_FIELDS).map(f => (
                    <span key={f} className="text-[10px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded">{f}</span>
                  ))}
                </div>
              </div>
            </div>

            {/* Preview */}
            {previewOpen && parseResults[0] && (
              <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
                <div className="flex items-center justify-between px-4 py-3 border-b border-slate-800">
                  <p className="text-sm font-medium text-white">
                    Preview · <span className="text-slate-400">{parseResults[0].sheetName}</span>
                  </p>
                  <button
                    onClick={() => setPreviewOpen(false)}
                    className="text-slate-500 hover:text-slate-300 text-xs"
                  >
                    Hide
                  </button>
                </div>
                <div className="overflow-x-auto scrollbar-thin">
                  <table className="w-full text-xs">
                    <thead className="bg-slate-800/50">
                      <tr>
                        {parseResults[0].rows.length > 0 &&
                          Object.keys(parseResults[0].rows[0]).slice(0, 8).map(col => (
                            <th key={col} className="text-left px-3 py-2 font-medium text-slate-300 whitespace-nowrap">{col}</th>
                          ))}
                      </tr>
                    </thead>
                    <tbody>
                      {parseResults[0].rows.slice(0, 5).map((row, i) => (
                        <tr key={i} className="border-t border-slate-800 hover:bg-slate-800/30">
                          {Object.keys(parseResults[0].rows[0]).slice(0, 8).map(col => (
                            <td key={col} className="px-3 py-2 text-slate-400 whitespace-nowrap max-w-[160px] truncate">
                              {String(row[col] ?? '')}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                {parseResults[0].rows.length > 5 && (
                  <p className="px-4 py-2 text-xs text-slate-500 border-t border-slate-800">
                    + {parseResults[0].rows.length - 5} more rows...
                  </p>
                )}
              </div>
            )}

            {/* Upload button */}
            <div className="flex items-center gap-3">
              <button
                onClick={uploadData}
                disabled={uploading || parseResults[0]?.rows.length === 0}
                className="flex-1 sm:flex-none inline-flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-medium px-5 py-2.5 rounded-lg transition-colors disabled:opacity-50"
              >
                {uploading ? <Loader2 size={14} className="animate-spin" /> : <Download size={14} />}
                {uploading ? 'Uploading...' : `Upload ${parseResults[0]?.rows.length ?? 0} rows`}
              </button>
              <button
                onClick={clearTable}
                className="inline-flex items-center gap-1.5 bg-slate-800 hover:bg-red-950/60 text-slate-400 hover:text-red-400 text-sm px-4 py-2.5 rounded-lg transition-colors"
              >
                <Trash2 size={13} />
                Clear {targetTable}
              </button>
            </div>
          </div>
        )}
        </>
        )}
      </div>
    </div>
  );
}
