import { useEffect, useState, useMemo } from 'react';
import { supabase } from '@/lib/supabase';
import { Asset, STATUS_BAR_COLORS } from '@/lib/types';
import AssetCard from '@/components/AssetCard';
import StatusBadge from '@/components/StatusBadge';
import { Search, Filter, CheckCircle2, Clock, AlertCircle, XCircle, BarChart3, Layers } from 'lucide-react';

const STATUSES = ['Deployed', 'POC On-going', 'Assess/Prepare', 'Rejected'];

export default function Dashboard() {
  const [assets, setAssets] = useState<Asset[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filterPractice, setFilterPractice] = useState('');
  const [filterCategory, setFilterCategory] = useState('');
  const [filterStatus, setFilterStatus] = useState('');

  useEffect(() => {
    async function load() {
      setLoading(true);
      const { data } = await supabase.from('assets').select('*').order('created_at', { ascending: false });
      setAssets(data ?? []);
      setLoading(false);
    }
    load();
  }, []);

  const practices = useMemo(() => [...new Set(assets.map(a => a.practice).filter(Boolean))].sort(), [assets]);
  const categories = useMemo(() => [...new Set(assets.map(a => a.category).filter(Boolean))].sort(), [assets]);

  const filtered = useMemo(() => {
    return assets.filter(a => {
      if (filterPractice && a.practice !== filterPractice) return false;
      if (filterCategory && a.category !== filterCategory) return false;
      if (filterStatus && a.status !== filterStatus) return false;
      if (search) {
        const q = search.toLowerCase();
        return (
          a.asset_name?.toLowerCase().includes(q) ||
          a.purpose?.toLowerCase().includes(q) ||
          a.benefit?.toLowerCase().includes(q) ||
          a.category?.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [assets, filterPractice, filterCategory, filterStatus, search]);

  const counts = useMemo(() => {
    const map: Record<string, number> = {};
    for (const s of STATUSES) map[s] = 0;
    for (const a of assets) {
      if (map[a.status] !== undefined) map[a.status]++;
      else if (a.status) map[a.status] = (map[a.status] ?? 0) + 1;
    }
    return map;
  }, [assets]);

  const deployedPct = assets.length ? Math.round((counts['Deployed'] / assets.length) * 100) : 0;

  const statCards = [
    { label: 'Total Assets', value: assets.length, icon: <Layers size={16} />, color: 'text-blue-400' },
    { label: 'Deployed', value: counts['Deployed'] ?? 0, icon: <CheckCircle2 size={16} />, color: 'text-emerald-400' },
    { label: 'In Progress', value: counts['POC On-going'] ?? 0, icon: <Clock size={16} />, color: 'text-blue-400' },
    { label: 'Assess/Prepare', value: counts['Assess/Prepare'] ?? 0, icon: <AlertCircle size={16} />, color: 'text-amber-400' },
    { label: 'Rejected', value: counts['Rejected'] ?? 0, icon: <XCircle size={16} />, color: 'text-red-400' },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero */}
      <section className="animated-gradient border-b border-slate-800">
        <div className="max-w-screen-xl mx-auto px-4 sm:px-6 py-10 sm:py-14">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-8">
            {/* Left: headline */}
            <div>
              <p className="text-xs text-blue-400 font-mono font-medium uppercase tracking-widest mb-2">A.T.D Platform</p>
              <h1 className="text-2xl sm:text-3xl font-bold text-white leading-tight">
                Feasibility Tracker
              </h1>
              <p className="mt-1.5 text-sm text-slate-400 max-w-md">
                Monitor automation deployment progress across all practices and accounts in one place.
              </p>
            </div>

            {/* Right: donut-style progress */}
            <div className="flex items-center gap-6">
              <div className="relative w-28 h-28 flex-shrink-0">
                <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90">
                  <circle cx="50" cy="50" r="40" fill="none" stroke="#1e293b" strokeWidth="10" />
                  <circle
                    cx="50" cy="50" r="40" fill="none"
                    stroke="#10b981" strokeWidth="10"
                    strokeDasharray={`${deployedPct * 2.51} 251`}
                    strokeLinecap="round"
                    style={{ transition: 'stroke-dasharray 1s ease' }}
                  />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className="text-2xl font-bold text-white">{deployedPct}%</span>
                  <span className="text-[9px] text-slate-400 uppercase tracking-widest">Deployed</span>
                </div>
              </div>
              <div className="flex flex-col gap-2">
                {STATUSES.map(s => (
                  <div key={s} className="flex items-center gap-2 text-xs">
                    <span className={`w-2 h-2 rounded-full ${STATUS_BAR_COLORS[s] ?? 'bg-slate-600'}`} />
                    <span className="text-slate-400 w-28">{s}</span>
                    <span className="text-white font-mono font-medium">{counts[s] ?? 0}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Status spectrum bar */}
          {assets.length > 0 && (
            <div className="mt-8">
              <div className="flex items-center gap-2 mb-2">
                <BarChart3 size={12} className="text-slate-500" />
                <span className="text-xs text-slate-500 uppercase tracking-widest font-medium">Status Distribution</span>
              </div>
              <div className="flex rounded-full overflow-hidden h-3">
                {STATUSES.map(s => {
                  const pct = assets.length ? (counts[s] ?? 0) / assets.length * 100 : 0;
                  if (!pct) return null;
                  return (
                    <div
                      key={s}
                      className={`${STATUS_BAR_COLORS[s] ?? 'bg-slate-600'} transition-all`}
                      style={{ width: `${pct}%` }}
                      title={`${s}: ${counts[s]}`}
                    />
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </section>

      {/* Stats */}
      <section className="max-w-screen-xl mx-auto px-4 sm:px-6 -mt-5">
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
          {statCards.map(card => (
            <div key={card.label} className="bg-slate-900 border border-slate-800 rounded-xl p-4">
              <div className={`flex items-center gap-1.5 mb-2 ${card.color}`}>
                {card.icon}
                <span className="text-xs font-medium">{card.label}</span>
              </div>
              <p className="text-2xl font-bold text-white font-mono">{card.value}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Filters */}
      <section className="max-w-screen-xl mx-auto px-4 sm:px-6 mt-8">
        <div className="flex flex-col sm:flex-row gap-3">
          {/* Search */}
          <div className="relative flex-1 min-w-0">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              type="text"
              placeholder="Search assets, purpose, benefit..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg pl-9 pr-4 py-2 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 transition-colors"
            />
          </div>

          {/* Practice filter */}
          <div className="relative">
            <Filter size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 pointer-events-none" />
            <select
              value={filterPractice}
              onChange={e => setFilterPractice(e.target.value)}
              className="appearance-none bg-slate-900 border border-slate-700 rounded-lg pl-8 pr-8 py-2 text-sm text-slate-300 focus:outline-none focus:border-blue-500 cursor-pointer"
            >
              <option value="">All Practices</option>
              {practices.map(p => <option key={p} value={p}>{p}</option>)}
            </select>
          </div>

          {/* Category filter */}
          <select
            value={filterCategory}
            onChange={e => setFilterCategory(e.target.value)}
            className="appearance-none bg-slate-900 border border-slate-700 rounded-lg px-4 py-2 text-sm text-slate-300 focus:outline-none focus:border-blue-500 cursor-pointer"
          >
            <option value="">All Categories</option>
            {categories.map(c => <option key={c} value={c}>{c}</option>)}
          </select>

          {/* Status filter */}
          <select
            value={filterStatus}
            onChange={e => setFilterStatus(e.target.value)}
            className="appearance-none bg-slate-900 border border-slate-700 rounded-lg px-4 py-2 text-sm text-slate-300 focus:outline-none focus:border-blue-500 cursor-pointer"
          >
            <option value="">All Statuses</option>
            {STATUSES.map(s => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>

        {/* Active filter chips */}
        {(filterPractice || filterCategory || filterStatus || search) && (
          <div className="flex flex-wrap items-center gap-2 mt-3">
            <span className="text-xs text-slate-500">Active filters:</span>
            {search && (
              <button onClick={() => setSearch('')} className="flex items-center gap-1 bg-slate-800 text-slate-300 text-xs px-2 py-0.5 rounded-full hover:bg-slate-700">
                "{search}" <span className="text-slate-500 ml-0.5">×</span>
              </button>
            )}
            {filterPractice && (
              <button onClick={() => setFilterPractice('')} className="flex items-center gap-1 bg-slate-800 text-slate-300 text-xs px-2 py-0.5 rounded-full hover:bg-slate-700">
                {filterPractice} <span className="text-slate-500 ml-0.5">×</span>
              </button>
            )}
            {filterCategory && (
              <button onClick={() => setFilterCategory('')} className="flex items-center gap-1 bg-slate-800 text-slate-300 text-xs px-2 py-0.5 rounded-full hover:bg-slate-700">
                {filterCategory} <span className="text-slate-500 ml-0.5">×</span>
              </button>
            )}
            {filterStatus && (
              <StatusBadge status={filterStatus} size="sm" />
            )}
            <button
              onClick={() => { setSearch(''); setFilterPractice(''); setFilterCategory(''); setFilterStatus(''); }}
              className="text-xs text-blue-400 hover:text-blue-300 underline"
            >
              Clear all
            </button>
          </div>
        )}
      </section>

      {/* Asset grid */}
      <section className="max-w-screen-xl mx-auto px-4 sm:px-6 py-6">
        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="bg-slate-900 border border-slate-800 rounded-xl p-4 h-40 animate-pulse" />
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-center">
            <div className="w-14 h-14 rounded-full bg-slate-800 flex items-center justify-center mb-4">
              <Search size={24} className="text-slate-600" />
            </div>
            <p className="text-slate-400 font-medium">No assets found</p>
            <p className="text-slate-600 text-sm mt-1">
              {assets.length === 0
                ? 'Upload data in the Admin Panel to get started.'
                : 'Try adjusting your filters.'}
            </p>
          </div>
        ) : (
          <>
            <div className="flex items-center justify-between mb-4">
              <p className="text-xs text-slate-500">
                Showing <span className="text-white font-medium">{filtered.length}</span> of {assets.length} assets
              </p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {filtered.map(asset => <AssetCard key={asset.id} asset={asset} />)}
            </div>
          </>
        )}
      </section>
    </div>
  );
}
