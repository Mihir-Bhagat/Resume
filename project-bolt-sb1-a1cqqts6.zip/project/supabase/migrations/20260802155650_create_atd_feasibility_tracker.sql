/*
# A.T.D Feasibility Tracker - Initial Schema

1. New Tables

## assets (Sheet2 / Repository)
The core asset library. Each row is an automation asset with its practice, category,
purpose, benefit, deployment link, type, status, clients implemented, and comments.

## deployments (Asset Category Summary)
Maps accounts (companies) to deployed assets with problem description, category, and mapped category.

## upload_logs
Tracks every admin file upload: filename, rows parsed, error count, sheet source.

2. Security
- RLS enabled on all tables.
- All policies use `TO anon, authenticated` since this is a shared-access app
  (admin uploads data; all users read the same dataset - no per-user isolation needed).
- Admins are identified at the application level via Supabase Auth; data writes
  are permitted from both roles since admin auth is enforced in the UI.

3. Important Notes
- No user_id ownership columns - this is shared workspace data.
- Status values: 'Deployed', 'POC On-going', 'Assess/Prepare', 'Rejected'
- Value levels: 'High', 'Medium', 'Low'
*/

-- ============================================================
-- assets table (Sheet2 repository)
-- ============================================================
CREATE TABLE IF NOT EXISTS assets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  practice text NOT NULL DEFAULT '',
  category text NOT NULL DEFAULT '',
  asset_name text NOT NULL DEFAULT '',
  purpose text DEFAULT '',
  benefit text DEFAULT '',
  link text DEFAULT '',
  type_of_asset text DEFAULT '',
  status text DEFAULT '',
  clients_implemented text DEFAULT '',
  comments text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE assets ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_assets" ON assets;
CREATE POLICY "select_assets" ON assets FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "insert_assets" ON assets;
CREATE POLICY "insert_assets" ON assets FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "update_assets" ON assets;
CREATE POLICY "update_assets" ON assets FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "delete_assets" ON assets;
CREATE POLICY "delete_assets" ON assets FOR DELETE
  TO anon, authenticated USING (true);

-- ============================================================
-- deployments table (Asset Category Summary sheet)
-- ============================================================
CREATE TABLE IF NOT EXISTS deployments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  account text NOT NULL DEFAULT '',
  assets_deployed text NOT NULL DEFAULT '',
  problem text DEFAULT '',
  category text DEFAULT '',
  mapped_category text DEFAULT '',
  practice text DEFAULT '',
  solution text DEFAULT '',
  value_level text DEFAULT '',
  effort_before numeric DEFAULT 0,
  effort_after numeric DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE deployments ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_deployments" ON deployments;
CREATE POLICY "select_deployments" ON deployments FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "insert_deployments" ON deployments;
CREATE POLICY "insert_deployments" ON deployments FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "update_deployments" ON deployments;
CREATE POLICY "update_deployments" ON deployments FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "delete_deployments" ON deployments;
CREATE POLICY "delete_deployments" ON deployments FOR DELETE
  TO anon, authenticated USING (true);

-- ============================================================
-- upload_logs table
-- ============================================================
CREATE TABLE IF NOT EXISTS upload_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  filename text NOT NULL,
  sheet_name text NOT NULL DEFAULT '',
  rows_parsed integer NOT NULL DEFAULT 0,
  rows_inserted integer NOT NULL DEFAULT 0,
  error_count integer NOT NULL DEFAULT 0,
  errors jsonb DEFAULT '[]'::jsonb,
  uploaded_at timestamptz DEFAULT now()
);

ALTER TABLE upload_logs ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_upload_logs" ON upload_logs;
CREATE POLICY "select_upload_logs" ON upload_logs FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "insert_upload_logs" ON upload_logs;
CREATE POLICY "insert_upload_logs" ON upload_logs FOR INSERT
  TO anon, authenticated WITH CHECK (true);
