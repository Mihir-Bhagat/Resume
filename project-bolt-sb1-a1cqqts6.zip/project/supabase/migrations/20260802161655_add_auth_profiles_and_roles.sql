/*
# Add profiles table with admin/user roles

1. New Tables
- `profiles`: one row per auth user, linked to auth.users via id.
  Stores the user's role ('admin' or 'user'), display name, and timestamps.
  The role column is server-controlled — users cannot set or change their own role.

2. Security
- RLS enabled on profiles.
- SELECT: authenticated users can read all profiles (shared workspace).
- UPDATE: users can only update their own display_name. The role column is NOT client-writable
  — UPDATE privilege on `role` is revoked from authenticated so only a SECURITY DEFINER
  function run by an admin can change it.
- `set_user_role` SECURITY DEFINER function: only an admin can call it to promote/demote users.

3. How roles work
- New signups automatically get role = 'user' via a database trigger.
- To make someone an admin, an existing admin calls set_user_role.
- Data tables (assets, deployments, upload_logs) now require authentication to read/write.

4. Important notes
- The role column carries privilege, so it must never be client-writable.
- Column-level UPDATE grant is narrowed to display_name only.
*/

-- ============================================================
-- profiles table
-- ============================================================
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text NOT NULL,
  display_name text DEFAULT '',
  role text NOT NULL DEFAULT 'user' CHECK (role IN ('admin', 'user')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_profiles" ON profiles;
CREATE POLICY "select_profiles" ON profiles FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "update_own_profile" ON profiles;
CREATE POLICY "update_own_profile" ON profiles FOR UPDATE
  TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "insert_own_profile" ON profiles;
CREATE POLICY "insert_own_profile" ON profiles FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = id);

-- ============================================================
-- Narrow column-level UPDATE: users can only change display_name, NOT role
-- ============================================================
REVOKE UPDATE ON profiles FROM authenticated;
GRANT UPDATE (display_name) ON profiles TO authenticated;

-- ============================================================
-- Trigger: auto-create a profile row on signup with default 'user' role
-- ============================================================
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, email, display_name, role)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'display_name', ''),
    'user'
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ============================================================
-- set_user_role: admin-only function to promote/demote users
-- ============================================================
CREATE OR REPLACE FUNCTION public.set_user_role(p_target_user uuid, p_role text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = auth.uid() AND role = 'admin'
  ) THEN
    RAISE EXCEPTION 'Not authorized';
  END IF;

  IF p_role NOT IN ('admin', 'user') THEN
    RAISE EXCEPTION 'Invalid role';
  END IF;

  UPDATE public.profiles SET role = p_role, updated_at = now()
  WHERE id = p_target_user;
END;
$$;

REVOKE EXECUTE ON FUNCTION public.set_user_role FROM anon;
GRANT EXECUTE ON FUNCTION public.set_user_role TO authenticated;

-- ============================================================
-- Tighten data tables to require authentication (no longer public)
-- ============================================================

-- assets
DROP POLICY IF EXISTS "select_assets" ON assets;
CREATE POLICY "select_assets" ON assets FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_assets" ON assets;
CREATE POLICY "insert_assets" ON assets FOR INSERT
  TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "update_assets" ON assets;
CREATE POLICY "update_assets" ON assets FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "delete_assets" ON assets;
CREATE POLICY "delete_assets" ON assets FOR DELETE
  TO authenticated USING (true);

-- deployments
DROP POLICY IF EXISTS "select_deployments" ON deployments;
CREATE POLICY "select_deployments" ON deployments FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_deployments" ON deployments;
CREATE POLICY "insert_deployments" ON deployments FOR INSERT
  TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "update_deployments" ON deployments;
CREATE POLICY "update_deployments" ON deployments FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "delete_deployments" ON deployments;
CREATE POLICY "delete_deployments" ON deployments FOR DELETE
  TO authenticated USING (true);

-- upload_logs
DROP POLICY IF EXISTS "select_upload_logs" ON upload_logs;
CREATE POLICY "select_upload_logs" ON upload_logs FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_upload_logs" ON upload_logs;
CREATE POLICY "insert_upload_logs" ON upload_logs FOR INSERT
  TO authenticated WITH CHECK (true);
